export default class CreateFileResult
{
    code = -1
}