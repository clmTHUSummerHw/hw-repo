export default class DownloadFileResult
{
    code = -1
    file = ""
}