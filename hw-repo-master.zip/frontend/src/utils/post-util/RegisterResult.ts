export default class RegisterResult
{
    code = -1
}