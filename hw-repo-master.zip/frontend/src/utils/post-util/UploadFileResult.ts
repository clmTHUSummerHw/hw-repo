export default class UploadFileResult
{
    code = -1
}