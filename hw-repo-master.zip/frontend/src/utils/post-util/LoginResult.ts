export default class LoginResult
{
    code = -1
    session = ""
}