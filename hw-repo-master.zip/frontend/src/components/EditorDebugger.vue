<template>
<!-- TODO: 填充内容 -->
</template>

<script lang="ts">
import { defineComponent } from 'vue';

export default defineComponent({
    //TODO: 填充内容（可以参考EditorConsole.vue）
})
</script>