<template>
    <div>
        <div id="project-list">
            <el-container class="box-base">
                <el-header class="box-header">
                    <!--顶部展示用户信息，flex容器-->
                    <div class="title">项目列表</div>
                    <!--用户信息展示栏-->
                    <div class="user-info">
                        <h3>用户信息</h3>
                        <a>用户名: </a>
                        <!--若为已登录用户，则显示用户名，否则显示一条杠-->
                        <a v-if="isLogin"> {{ userStore.username }} </a>
                        <a v-else> - </a>

                        <a>登录状态: </a>
                        <el-tag class="ml-2" type="success" v-if="isLogin">已登录</el-tag>
                        <el-tag class="ml-2" type="danger" v-else>未登录</el-tag>
                    </div>
                    <!--TODO: 展示用户详细信息-->
                </el-header>

                <el-main class ="box-list">
                    <!--展示项目包含项目列表的表格-->
                    <el-table :data="projectData" style="width: 100%">
                        <el-table-column label = "ProjectName" width = "150" >
                            <template #default = "scope">
                                <el-button
                                    link
                                    type = "primary"
                                    size = "small"
                                    @click="deletePro(scope.$index)"
                                >
                                    Delete
                                </el-button>
                            
                            
                            
                                <el-button
                                    link
                                    type = "primary"
                                    size = "small"
                                    @click="OpenPro(scope.$index)"
                                >
                                    Open
                                </el-button>                                
                            </template>
                        </el-table-column>
                    </el-table>
                </el-main>

                <el-footer>
                    <!--创建项目按钮区域-->
                    <el-button class="remote" type="primary" @click="remotePro" round>创建远程项目</el-button>
                    <el-button class="local" type="primary" @click="localPro" round>创建本地项目</el-button>
                </el-footer>
            </el-container>
        </div>

        <!--创建项目时弹出对话框-->
        <el-dialog :visible.sync = "getmessage">
            <el-form>
                <el-form-item label="项目名称" prop="proname">
                    <el-input placeholder="请输入项目名称" v-model="form.username"></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button class="submit" type="primary" @click="proSummon" round>确认</el-button>
                    <!--round只是设置形状-->
                </el-form-item>
            </el-form>

        </el-dialog>
    </div>
</template>

<script lang="ts">
import { defineComponent } from "vue";
import { useUserStore } from "@/stores/user";

export default defineComponent({
    name: "ProjectList",
    data()
    {
        return {
            getmessage:false, //默认不弹出对话框
            isLogin: false, //是否为注册过的用户
            projectData: [], //table中项目信息
            proname: "",
            session: "",
            username: ""
        }
    },

    computed: {
        userStore()
        {
            return useUserStore();
        }
    },

    async mounted() //如需要使用async，直接把这里改为async mounted()
    {
        //TODO: 加载用户信息及项目信息（从pinia加载一部分，通过post请求获得另一部分）（尽量使用async，不要嵌套回调函数）
        const store = this.userStore();
        this.username = store.username;
        this.session = store.session;
        this.isLogin = this.$route.query.islogin;
        const response = await this.axios.post("http://127.0.0.1:8080/list_projects");
            if(!response.ok){
                throw new Error('HTTP 请求错误：${response.status}');
            }
            const projectList = await response.json();
            if(response.json['code'] == -1){
                alert("未知错误！")
            }
            else if(response.json['code'] == 1){
                alert("session无效")
            }
            else if(response.json['code'] == 0){
                this.projectData = projectList['projects'];
                alert("获取成功！")


            }       

    },
    methods: {
        localPro(){
            this.getmessage = true
        },

        async proSummon(){
            try {
                const response = await this.axios.post("http://127.0.0.1:5000/new_project");
                if(!response.ok){
                    throw new Error('HTTP 请求错误：${response.status}');
                }
                const newProject = await response.json();
                if(response.json['code'] == -1){
                    alert("未知错误！")
                }
                else if(response.json['code'] == 1){
                    alert("session无效")
                }
                else if(response.json['code'] == 2){
                    alert("项目名不合规范")
                }
                else if(response.json['code'] == 0){
                    this.projectData.append(this.proname)
                    alert("创建成功！")
                    this.proname = ""
                    this.getmessage = false

                }
                
            }
            catch(error){
                console.error("创建项目出现问题")
            }
        },

        deletePro(index){
            const proName = this.projectData[index]
            const response = this.axios.post("http://127.0.0.1:8080/delete_project")
            this.projectData.splice(index,1);
        },

        OpenPro(index){
            const proName = this.projectData[index];
            this.$route.push({path: '/editor', query:{proname:proName}})
        }
    }
})

</script>

<style lang="scss">
#project-list
{
    font-family: Avenir, Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-align: center;
    color: #2c3e50;

    box-sizing: border-box;
    width: 100%;
    height: 800px;
    background-image: url(@/assets/small_logo_bg.png);

    .box-base
    {
        /* 整体框 */
        color: black;
        background-color: white;
        box-shadow: 1px 0 10px rgb(0 0 0 / 30%);

        margin: auto;
        width: 90%;
        height: 600px;

        position: relative;
        top: 7%;
    }

    .box-header
    {
        /* 顶部展示当前用户信息 */
        padding: 0;

        display: flex;
        align-items: center;

        border-bottom: 1px solid grey;
    }

    .title
    {
        /* “项目列表” 字体设置 */
        font-size: 36px;
        height: 58px;
        flex-grow: 1;
    }

    .user-info
    {
        /* 调整用户信息栏的flex-grow */
        flex-grow: 4;

        h3
        {
            /* 调整用户信息栏标题上下margin */
            margin-top: 0;
            margin-bottom: 5px;
        }
    }
}
</style>