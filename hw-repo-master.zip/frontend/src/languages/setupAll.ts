import Java from '@/languages/java.js';

export default {
    setup()
    {
        Java.setup();
    }
}
