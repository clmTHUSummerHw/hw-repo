declare module '@/languages/java.js'
{
    export default {
        setup(): void
    }
}