# 后端部分

此部分存放后端代码

后端使用MySql作为数据库，运行前，需要先下载安装MySql（推荐其开源版本MariaDB）。
第一次运行后端，需要先按照create_db.sql创建用户和数据库，再运行create_db.py，最后根据launch.json的配置启动后端。