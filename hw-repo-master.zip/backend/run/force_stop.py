def force_stop(data):
    pass#TODO: 强行停止项目