def step_out(data):
    pass # 调试器执行步出操作