def query_value(data):
    pass# 查询变量值，并发送回前端