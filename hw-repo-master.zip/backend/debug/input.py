def input(data):
    pass #TODO: 获取输入，并传递给项目