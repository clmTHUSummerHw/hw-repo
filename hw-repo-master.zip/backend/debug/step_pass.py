def step_pass(data):
    pass # 调试器执行步过操作