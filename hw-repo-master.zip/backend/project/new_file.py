from struct import pack
from flask import request


def new_file():
    pass