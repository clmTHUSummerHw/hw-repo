from flask import request


def new_folder():
    pass