from flask import request


def delete_folder():
    pass