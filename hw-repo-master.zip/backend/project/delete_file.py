from flask import request


def delete_file():
    pass