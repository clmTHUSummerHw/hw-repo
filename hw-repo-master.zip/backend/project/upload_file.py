from flask import request


def upload_file():
    pass