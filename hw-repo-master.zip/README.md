# 2022夏季学期大作业

**项目名称：** Thide

**项目Logo：** ![](./doc/images/logo.png)

**小型Logo：** ![](./doc/images/small_logo.png)

**小组成员：**
* 刘子骜
* 朴灿彬
* 李一宣
* 张仕炫
* 张子昂
* 王双

**其他：**
* [文档部分README](./doc/README.md)
* [前端代码部分README](./frontend/README.md)
* [后端代码部分README](./backend/README.md)
